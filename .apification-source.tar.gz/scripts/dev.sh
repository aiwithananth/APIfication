#!/usr/bin/env bash
# Start the APIfication control plane (FastAPI :8000) and web UI (Next.js :3000) for local development.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
API="$ROOT/services/control-plane"
WEB="$ROOT/apps/web"

PY="${PYTHON:-python3}"
"$PY" -c 'import sys; assert sys.version_info >= (3, 10), "Python 3.10+ required"' || exit 1
command -v node >/dev/null || { echo "Node.js 20+ is required"; exit 1; }

if [ ! -d "$API/.venv" ]; then
  echo "→ Creating Python virtualenv"
  "$PY" -m venv "$API/.venv"
fi
# shellcheck disable=SC1091
source "$API/.venv/bin/activate"
pip install -q -r "$API/requirements-dev.txt"

if [ ! -d "$WEB/node_modules" ]; then
  echo "→ Installing web dependencies"
  (cd "$WEB" && npm install --no-audit --no-fund)
fi

cleanup() { kill 0 2>/dev/null || true; }
trap cleanup EXIT INT TERM

echo "→ Control plane on http://localhost:8000  (API docs: /docs)"
(cd "$API" && uvicorn app.main:app --reload --host 127.0.0.1 --port 8000) &
echo "→ Web UI on http://localhost:3000"
(cd "$WEB" && npm run dev) &
wait
